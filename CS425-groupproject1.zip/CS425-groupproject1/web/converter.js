var Lab4 = (function () {

    var rates = null;

    var createCurrencyMenu = function (currencies) {

        $("#div1").load("https://testbed.jaysnellen.com:8443/JSUExchangeRatesServer/rates?date=2022-09-21");

        $.ajax({
            url:"https://testbed.jaysnellen.com:8443/JSUExchangeRatesServer/rates",
            url:"https://testbed.jaysnellen.com:8443/JSUExchangeRatesServer/currencies",
            method:'get',
            datatype:'json',
            success:function(response){
                rates = response

            $("#div1").html(response);
            }
        }
    ,)};

    var convert = function () {

        var rate_date = rates["date"];
        var rates_usd = Number (rates["rates"]["usd"]);
        var rates_gbp = Number (rates["rates"]["gpb"]);

        var usd_value = Number($("#usd_value").val());

        console.log("USD: " +  rates_usd + " , GBP " + rates_gbp);

        var target_value_euro = usd_value / usd_value;
        var target_value_final = target_value_euro * target_rate;

        var usd_value_string = (usd_value).toLocaleString('en-US', {
            style: 'currency',
            currency: 'USD',
        });

    };

    var getRatesAndConvert = function (rate_date) {

        console.log("Getting rates for " + rate_date + " ...");
        
    };

    return {

        getCurrenciesList: function () {

            var getRatesAndConvert = function (rate_date) {

                console.log("Getting rates for " + rate_date + " ...");
        
                function getResults() {
                    fetch(`${api}`)
                        .then(currency => {
                            return currency.json();
                        }).then(displayResults);
                }};

        },

        onClick: function () {

            var rate_date = $("#rate_date").val();

            if (rate_date === "") {
                alert("Please enter or select a date in the \"Date\" field!");
            }
            else {

                // if rates have not been retrieved yet, or if the date is different, fetch new rates

                if ((rates === null) || (rate_date !== rates["date"])) {
                    getRatesAndConvert(rate_date);
                }

                // if rates for the selected date are already available, perform the conversion

                else {
                    convert();
                }

            }

        }

    };

})();